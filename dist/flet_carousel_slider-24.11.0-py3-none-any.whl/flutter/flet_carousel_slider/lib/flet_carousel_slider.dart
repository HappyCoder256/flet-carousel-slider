library flet_carousel_slider;

export "../src/create_control.dart" show createControl, ensureInitialized;
